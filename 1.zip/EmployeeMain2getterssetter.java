package oop;

public class EmployeeMain2getterssetter {

	public static void main(String[] args) {
		Employee2getterssetters s2= new Employee2getterssetters();
		s2.setSalary(50000);
		System.out.println(s2.getSalary());
		
		
		s2.setName("nandini");
		System.out.println(s2.getSalary());
	}

}
