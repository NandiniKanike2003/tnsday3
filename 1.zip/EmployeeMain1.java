package oop;

public class EmployeeMain1 {

	public static void main(String[] args) {
		Employee1 s1= new Employee1();
		s1.salary=50000;
		System.out.println(s1.salary);

	}

}
