package oop;

public class StudentMain2getterssetter {

	public static void main(String[] args) {
		Student2getterssetters s2= new Student2getterssetters();
		s2.setAge(30);
		System.out.println(s2.getAge());
		
		
		s2.setName("nandini");
		System.out.println(s2.getAge());
	}

}
