package oop;

public class Employee1 {
private String name;
private String id;
private String address;
public int salary ;


}
