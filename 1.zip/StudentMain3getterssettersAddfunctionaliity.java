package oop;

public class StudentMain3getterssettersAddfunctionaliity {

	public static void main(String[] args) {
		Student3getterssettersAddfunctinality student = new Student3getterssettersAddfunctinality ();
		student.setAge (30);
		student.setName ("nandini");
		student.setId ("3325");
		student.setAddress ("hyderabad");
		//calling the function
		System.out.println (student.run ());
		

	}

}
