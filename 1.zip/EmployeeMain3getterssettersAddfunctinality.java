package oop;

public class EmployeeMain3getterssettersAddfunctinality {

	public static void main(String[] args) {
		Employee3getterssettersAddfunctinality employee = new Employee3getterssettersAddfunctinality ();
		employee.setSalary (50000);
		employee.setName ("nandini");
		employee.setId ("3325");
		employee.setAddress ("hyderabad");
		//calling the function
		System.out.println (employee.run ());
		
		

	}

}
