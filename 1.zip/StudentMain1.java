package oop;

public class StudentMain1 {

	public static void main(String[] args) {
		Student1 s1= new Student1();
		s1.age=30;
		System.out.println(s1.age);
	}

}
