package oop;

public class Student1 {
	private String name;
	private String id;
	private String address;
	public int age ;

}
